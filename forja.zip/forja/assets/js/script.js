'use strict';

/**
 * navbar variables
 */

const navOpenBtn = document.querySelector("[data-menu-open-btn]");
const navCloseBtn = document.querySelector("[data-menu-close-btn]");
const navbar = document.querySelector("[data-navbar]");
const overlay = document.querySelector("[data-overlay]");

const navElemArr = [navOpenBtn, navCloseBtn, overlay];

for (let i = 0; i < navElemArr.length; i++) {

  navElemArr[i].addEventListener("click", function () {

    navbar.classList.toggle("active");
    overlay.classList.toggle("active");
    document.body.classList.toggle("active");

  });

}

  

function toggleHeart(event, button) {
  event.preventDefault();  // Prevent any default action, like navigating away from the page
  const heartIcon = button.querySelector('.heart-icon'); // Select the heart icon inside the button

  // Toggle the 'liked' class on the heart icon to change its color and style
  heartIcon.classList.toggle('liked');

  // Check if the icon is liked and update its icon accordingly
  if (heartIcon.classList.contains('liked')) {
      heartIcon.setAttribute('name', 'heart');  // Change icon to filled heart
  } else {
      heartIcon.setAttribute('name', 'heart-outline');  // Change icon back to outline
  }

  // Now trigger form submission
  // Assuming the button is inside a form and contains a 'name' attribute for the action
  const form = button.closest('form');  // Get the closest form to the button
  form.submit();  // Submit the form when the heart is clicked
}






/**
 * header sticky
 */

const header = document.querySelector("[data-header]");

window.addEventListener("scroll", function () {

  window.scrollY >= 10 ? header.classList.add("active") : header.classList.remove("active");

});



/**
 * go top
 */

const goTopBtn = document.querySelector("[data-go-top]");

window.addEventListener("scroll", function () {

  window.scrollY >= 500 ? goTopBtn.classList.add("active") : goTopBtn.classList.remove("active");

}
);