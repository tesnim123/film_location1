document.getElementById('genres-form').addEventListener('submit', function(event) {
    const selectedGenres = document.querySelectorAll('input[name="genre"]:checked');
    
    if (selectedGenres.length !== 3) {
        event.preventDefault();
        document.getElementById('error-message').style.display = 'block';
    } else {
        document.getElementById('error-message').style.display = 'none';
    }
});
