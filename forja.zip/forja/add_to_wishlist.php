<?php
// Include the connection file
include 'connection/connect.php';
session_start();

// Check if user is logged in by checking the session username
if (!isset($_SESSION['username'])) {
    die('You must be logged in to add a movie to your wishlist.');
}

// Get the username from the session
$username = $_SESSION['username'];

// Fetch the user_id from the database based on the username
$stmt = $conn->prepare('SELECT user_id FROM users WHERE username = ? LIMIT 1');
$stmt->bind_param('s', $username);  // 's' for string type
$stmt->execute();
$stmt->store_result();

// If the username is found, fetch the user_id
if ($stmt->num_rows > 0) {
    $stmt->bind_result($user_id);
    $stmt->fetch();
} else {
    die('User not found.');
}
$stmt->close();

// Get the movie_id from the GET parameter
$movie_id = isset($_GET['movie_id']) ? intval($_GET['movie_id']) : 0;

// Validate movie_id
$stmt = $conn->prepare('SELECT 1 FROM movies WHERE movie_id = ?');
$stmt->bind_param('i', $movie_id);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows === 0) {
    die('Invalid movie ID.');
}
$stmt->close();

// Check if the movie is already in the wishlist
$stmt = $conn->prepare('SELECT * FROM wishlist WHERE user_id = ? AND movie_id = ?');
$stmt->bind_param('ii', $user_id, $movie_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Wishlist</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 400px;
            text-align: center;
        }

        h1 {
            color: #333;
            font-size: 24px;
        }

        .message {
            font-size: 18px;
            color: #555;
            margin: 20px 0;
        }

        .success {
            color: #4CAF50;
            font-weight: bold;
        }

        .error {
            color: #F44336;
            font-weight: bold;
        }

        .button {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        .button:hover {
            background-color: #0056b3;
        }

    </style>
</head>
<body>

<div class="container">
    <?php if ($result->num_rows > 0): ?>
        <p class="message error">This movie is already in your wishlist.</p>
    <?php else: ?>
        <?php
        // Insert the movie into the wishlist
        $stmt = $conn->prepare('INSERT INTO wishlist (user_id, movie_id) VALUES (?, ?)');
        $stmt->bind_param('ii', $user_id, $movie_id);

        if ($stmt->execute()) {
            echo '<p class="message success">The movie has been added to your wishlist!</p>';
        } else {
            echo '<p class="message error">Failed to add the movie to the wishlist. Error: ' . $stmt->error . '</p>';
        }

        $stmt->close();
        ?>
    <?php endif; ?>
    <a href="wishlist.php" class="button">Go to Wishlist</a>
</div>

</body>
</html>
